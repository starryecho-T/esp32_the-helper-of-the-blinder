/**
 * TTS 语音合成模块测试（VTX316）
 * 客服客服发来的程序，加详细注释说明
 *
 * 这是 VTX316 芯片
 * 通过串口发送文字，芯片自动合成语音播放，需外接喇叭
 *
 * 接线：
 *   VTX316 RX  ←  GPIO14（ESP32 TX 发给 TTS）
 *   VTX316 TX  →  GPIO3（ESP32 RX 接收 TTS 返回，不接也行）
 *   VTX316 GND → GND
 *   VTX316 VCC → 5V
 *   喇叭接 VTX316 喇叭输出口
 */

#define TTS_RX_PIN 14   // ESP32 TX → TTS RX
#define TTS_TX_PIN 3   // tts TX → ESP32 RX（不接也行）

HardwareSerial voiceSerial(2);

/*********************************
 * 语音播报
 *********************************/
void Voice_BOBAO(const char *message)
{
  size_t byteLength = strlen(message);

  uint8_t headOfFrame[5] = {
    0xFD,
    0x00,
    (uint8_t)(byteLength + 2),
    0x01,
    0x05
  };

  voiceSerial.write(headOfFrame, sizeof(headOfFrame));
  delay(2);

  voiceSerial.print(message);

  delay(byteLength * 12 + 300);
}

/*********************************
 * 音量设置 0-10
 *********************************/
void Voice_YIN_LIANG(uint8_t YINLIANG)
{
  uint8_t command[9] = {0xFD, 0x00, 0x06, 0x01, 0x01, 0x5B, 0x76, 0x30 + YINLIANG, 0x5D};
  voiceSerial.write(command, sizeof(command));
}

/*********************************
 * 暂停播报
 *********************************/
void Voice_ZANTING()
{
  uint8_t command[4] = {0xFD, 0x00, 0x01, 0x03};
  voiceSerial.write(command, sizeof(command));
}

/*********************************
 * 恢复播报
 *********************************/
void Voice_HUIFU()
{
  uint8_t command[4] = {0xFD, 0x00, 0x01, 0x04};
  voiceSerial.write(command, sizeof(command));
}

void setup() {
  Serial.begin(115200);
  Serial.println("TTS 语音合成测试");
  Serial.println("引脚：RX=14, TX=3");
  delay(1000);

  Voice_YIN_LIANG(1);
  delay(100);
  Voice_BOBAO("雨天路面湿滑，请注意安全");
  delay(3000);

  Voice_YIN_LIANG(7);
  delay(100);
  Voice_BOBAO("今天天气晴，适合外出");
  delay(3000);

  Serial.println("测试完成");
}

void loop() {
}
